﻿using System;

namespace AgeCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your date of birth formate like MM/dd/yyyy");
            DateTime givenDate = Convert.ToDateTime(Console.ReadLine());

            DateTime Now = DateTime.Now;
            int Years = new DateTime(DateTime.Now.Subtract(givenDate).Ticks).Year - 1;
            DateTime PastYearDate = givenDate.AddYears(Years);
            int Months = 0;
            for (int i = 1; i <= 12; i++)
            {
                if (PastYearDate.AddMonths(i) == Now)
                {
                    Months = i;
                    break;
                }
                else if (PastYearDate.AddMonths(i) >= Now)
                {
                    Months = i - 1;
                    break;
                }
            }
            int Days = Now.Subtract(PastYearDate.AddMonths(Months)).Days;
            int Hours = Now.Subtract(PastYearDate).Hours;
            int Minutes = Now.Subtract(PastYearDate).Minutes;
            int Seconds = Now.Subtract(PastYearDate).Seconds;
          


           
                Console.WriteLine("Current Age = " + Years + " Years  "  + Months  +  " Months  "+ Days + " Days  "  + Hours + " Hours  "+ Seconds + " Seconds ");
           
            Console.ReadKey();
           // Console.WriteLine("Hello World!");
        }
    }
}
