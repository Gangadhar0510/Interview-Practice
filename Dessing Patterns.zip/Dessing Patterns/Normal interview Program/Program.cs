﻿using System;

namespace Normal_interview_Program
{
    public class Program
    {
        static string location;
        static DateTime time;
        static void Main(string[] args)
        {
            Console.Write(location == null ? "Loaction is nul" : location);
            Console.Write(time == null ? "time is nul" : time.ToString());
        }
    }
}
