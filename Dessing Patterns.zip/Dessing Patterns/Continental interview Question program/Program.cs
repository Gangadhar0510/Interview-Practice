﻿using System;
using System.Collections.Generic;

namespace Continental_interview_Question_program
{
    class Program
    {
        static void Main(string[] args)
        {
            bool error = false;
            var str = "({[Gangadhar])}";
            Stack<char> stack = new Stack<char>();
            Stack<char> stackclose = new Stack<char>();
            foreach (var item in str.ToCharArray())
            {
                if (item == '(' || item == '{' || item == '[')
                {
                    stack.Push(item);
                }
                else if (item == ')' || item == '}' || item == ']')
                {
                    stackclose.Push(item);
                   
                   
                }
            }
            if (stack.Count != stackclose.Count)
            {
                error = true;
            }
            else
            {
                foreach (var item1 in str.ToCharArray())
                {
                    if (stack.Count != 0)
                    {
                        if (item1 == ')' || item1 == '}' || item1 == ']')
                        {
                            if (stack.Peek() != GetComplementBracket(item1))
                            {
                                error = true;
                                break;
                            }
                            stack.Pop();
                        }
                       
                    }
                }
            }

            if (error)
                Console.WriteLine("Incorrect brackets");
            else
                Console.WriteLine("Brackets are fine");
            Console.ReadLine();
        }

        private static char GetComplementBracket(char item)
        {
            switch (item)
            {
                case ')':
                    return '(';
                case '}':
                    return '{';
                case ']':
                    return '[';
                default:
                    return ' ';
            }
        }
    }
}
