﻿using System;
using System.Collections;

namespace ADP_interview_Question
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num1 = { 1, 2, 3, 0, 4, 0, 5 };
            int[] num2 = new int[7];
            ArrayList arr = new ArrayList();

            int j= 0;

            for(int i =0; i<num1.Length; i++)
            {
                if(num1[i] != 0)
                {
                    arr[j] = num1[i];

                    j++;

                   
                }

            }

            foreach (var item in arr)
            {
                Console.WriteLine(item);
            }
            Console.Read();
        }
    }
}
