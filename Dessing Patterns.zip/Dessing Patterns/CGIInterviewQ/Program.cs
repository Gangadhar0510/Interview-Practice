﻿using System;

namespace CGIInterviewQ
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "php";
            string reverse = "";
            //int h = 0;

            for(int i = str.Length -1 ; i >= 0; i--)
            {
                reverse += str[i];
            }

            if (reverse == str)
            {
                Console.WriteLine("Palindrome");
            }
            else
            {
                Console.WriteLine("not");
            }
            Console.Read();
        }
    }
}
