﻿using System;

namespace Dessing_Patterns
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--Start--");
            ProductDelhFactory sf = new StandardDelivery();
            Client standard = new Client(sf);
            var clientpack = standard.ClientPackaging.GetType();
            var clientDoc = standard.ClientDocument.GetType();
            Console.WriteLine(clientpack + "\n" + clientDoc);

            ProductDelhFactory df = new DelicatePackaging();
            Client delicate = new Client(df);
           // Client del = new Client();
            var delPac = delicate.ClientPackaging.GetType();
            var delDoc = delicate.ClientDocument.GetType();
            Console.WriteLine(delPac + "\n" + delDoc);
        }
        //client class
        public class Client
        {
            //constructor 
            public Client(ProductDelhFactory factory)
            {
                ClientPackaging = factory.CreatePackaging();
                ClientDocument = factory.CreateDeliveryDocument();
            }
          

            //properties
            public Packaging ClientPackaging { get; }
            public DeliveryDocument ClientDocument { get; }
        }
        //Factory class only abstract methods 
        public abstract class ProductDelhFactory
        {
            public abstract Packaging CreatePackaging();
            public abstract DeliveryDocument CreateDeliveryDocument();
        }
        //Concrete class1 inherit abstract factory method
        public class StandardDelivery : ProductDelhFactory
        {
            public override Packaging CreatePackaging()
            {
                return new Postal();
            }

            public override DeliveryDocument CreateDeliveryDocument()
            {
                return new StandingPackaging();
            }
        }
        //Concrete class2 inherit abstract factory method
        public class DelicatePackaging : ProductDelhFactory
        {
            public override Packaging CreatePackaging()
            {
                return new Courier();
            }
            public override DeliveryDocument CreateDeliveryDocument()
            {
                return new ShockProofPackaging();
            }
        }

        //abstract class 
        public abstract class Packaging { }
        //inherit abstract class
        public class Postal : Packaging { }
        public class Courier : Packaging { }
        

        public abstract class DeliveryDocument { }
        public class StandingPackaging : DeliveryDocument { }
        public class ShockProofPackaging : DeliveryDocument { }
    }




}
