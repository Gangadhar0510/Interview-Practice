﻿using System;

namespace Struct
{
    class Program
    {
        static void Main(string[] args)
        {

             Location a = new Location(20,20);
             Location b = a;
             a.x = 100;

            Console.WriteLine(b.x);
            Console.ReadKey();
        }
        
    }

    struct Location
    {
        public int x, y;
        public Location(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

    }
}
