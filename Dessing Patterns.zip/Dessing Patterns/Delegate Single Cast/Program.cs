﻿using System;


namespace Delegate_Single_Cast
{
    public class Maths
    {
        public delegate void AddNum(int a, int b);
        public delegate void SubNum(int a, int b);

        public void Add(int a, int b)
        {
            Console.WriteLine(a + b);
        }
        public void Sub(int a, int b)
        {
            Console.WriteLine(a - b);
        }


        class Program
        {
            static void Main(string[] args)
            {
                Maths mht = new Maths();

                AddNum deladd = new AddNum(mht.Add);
               // Console.Read(a);
                deladd(100, 200);
                SubNum delsub = new SubNum(mht.Sub);
                delsub(20, 45);
            }
            //Console.Readkey();
        }
    }
}
