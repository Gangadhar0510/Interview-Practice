﻿using System;

namespace Matrix_program
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

       
    }
}
