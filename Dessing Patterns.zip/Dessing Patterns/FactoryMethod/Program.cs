﻿using System;

namespace FactoryMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");

            Vehiclefactory factory = new Concretevehiclefactory();

            IFactory Sc = factory.GetVehicle("Scooter");
            Sc.Drive(10);
            IFactory car = factory.GetVehicle("Car");
            car.Drive(100);
            IFactory bike = factory.GetVehicle("Bike");
            bike.Drive(2000);

            Console.ReadKey();

        }

        //Interface factory
        public interface IFactory
        {
            void Drive(int miles);
            void Drive(string distance);

            void VehicleType(string Name);
        }

        public interface IEngine
        {
            void Drive(int miles);
        }

        //concerte product 
        public class Scooter : IFactory, IEngine
        {
            public void VehicleType(string Name)
            {
                Console.WriteLine("Scooter");
            }

            void IFactory.Drive(int miles)
            {
                Console.WriteLine("Dive Scooter -->" + miles.ToString());
            }

            public void Drive(string distance)
            {
                throw new NotImplementedException();
            }

            public void Drive(int miles)
            {
                throw new NotImplementedException();
            }
        }
        public class car : IFactory
        {
            public void VehicleType(string Name)
            {
                Console.WriteLine("CAR");
            }
            public void Drive(int miles)
            {
                Console.WriteLine("Dive Car -->" + miles.ToString());
            }

            public void Drive(string distance)
            {
                throw new NotImplementedException();
            }
        }
        public class Bike : IFactory
        {
            public void VehicleType(string Name)
            {
                Console.WriteLine("BIKE");
            }
            public void Drive(int miles)
            {
                Console.WriteLine("Dive Bike -->" + miles.ToString());
            }

            public void Drive(string distance)
            {
                throw new NotImplementedException();
            }
        }
        //Factory Creator 
        public abstract class Vehiclefactory
        {
            public abstract IFactory GetVehicle(string vehicle);
        }
        //Factory ConcreteCreator
        public class Concretevehiclefactory: Vehiclefactory
        {
            public override IFactory GetVehicle(string vehicle)
            {
                switch (vehicle)
                {
                    case "Scooter":
                        return new Scooter();
                    case "Car":
                        return new car();
                    default:
                        return new Bike(); 
                }       
            }
        }
    }
}
