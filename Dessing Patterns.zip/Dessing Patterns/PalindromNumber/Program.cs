﻿using System;

namespace PalindromNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0, rem, num = 121, temp;

            temp = num;

            while(num > 0)
            {
                rem = num % 10;
                num = num / 10;
                sum = sum * 10 + rem;

            }
            if(temp == sum)
            {
                Console.WriteLine("Palindrome");
            }
            else
            {
                Console.WriteLine("Not Palindrome");
            }
            
        }
    }
}
