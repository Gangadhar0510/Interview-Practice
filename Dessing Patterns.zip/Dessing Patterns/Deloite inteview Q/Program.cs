﻿using System;

namespace Deloite_inteview_Q
{
    class Program
    {
        static void Main(string[] args)
        {
           
            B obj2 = new C();
            C obj = new C();
            B obj3 = new B();

           
             
            obj2.method();
            obj.method2();
            obj3.method();
            
           
            
            Console.WriteLine("Hello World!");
        }

        public class B
        {
            public B()
            {

            }
            public void method()
            {

            }
        }
        public class C : B
        {
            public C()
            {

            }
            public void method2()
            {

            }
        }
    }
}
