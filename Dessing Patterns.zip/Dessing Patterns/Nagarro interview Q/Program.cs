﻿using System;

namespace Nagarro_interview_Q
{
    class Program
    {
       // string input1;
        static void Main(string[] args)
        {

            string Input1 = Console.ReadLine();
            Result result = FindLongestMessage(Input1);
            result.output1 = Convert.ToInt32(result.output2.Length);
            Console.WriteLine(result.output1 +"\n"+ result.output2);
            Console.Read();
        }

        private static Result FindLongestMessage(string input1)
        {
            Result r = new Result();
            char[] charArray = input1.ToCharArray();
            Array.Reverse(charArray);
            char[] ch = charArray;
            char[] ch1 = charArray;


            for (int i = 0; i < ch1.Length-1; i++)
            {
                for (int j = 0; j < ch.Length; j++)
                {
                    if (ch[i] == ch[j])
                    {
                        r.output2 += ch[j].ToString();
                        
                    }                    
                }
                break;
            }
            return r;
        }

        public class Result
        {
            public int output1;
            public string output2;
        }
       
    }
}
