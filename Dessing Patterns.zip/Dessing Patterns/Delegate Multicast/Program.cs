﻿using System;

namespace Delegate_Multicast
{
    public class MulticastDelegate
    {
        //Access Modifier, delegate, return type, methodname and Parameters
        public delegate void RectangleDelegate(double height, double width);

        public void Area(double height, double width)
        {
            Console.WriteLine("Area = " + (height + width));
        }
        public void Perimeter(double height, double width)
        {
            Console.WriteLine("Perimeter = " + 2 *( height + width));
        }
        class Program
        {
            static void Main(string[] args)
            {
                MulticastDelegate ms = new MulticastDelegate();

                RectangleDelegate recDel = new RectangleDelegate(ms.Area);
               // recDel(12.5, 15.5);

                recDel += ms.Perimeter;

                recDel.Invoke(1, 2);

                Console.Read();
            }
        }
    }
}
